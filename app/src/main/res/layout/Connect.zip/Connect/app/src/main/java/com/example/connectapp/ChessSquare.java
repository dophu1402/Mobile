package com.example.connectapp;

public class ChessSquare {
    boolean touchOn;
    boolean player;
    public ChessSquare(boolean ntouch, boolean nplayer)
    {
        touchOn = ntouch;
        player = nplayer;
    }
}
